-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 12, 2019 at 04:30 PM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_mvc_pat`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `title` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `name`, `title`) VALUES
(1, 'Education', 'Education'),
(2, 'Health', 'Health'),
(3, 'Tech', 'Tech'),
(4, 'Lifestyle', 'Lifestyle'),
(5, 'Sports', 'Sports'),
(14, 'National Politics', 'National Politics'),
(9, 'Business', 'Business'),
(12, 'Fashion', 'Fashion'),
(16, 'Film, Movies', 'Film, Movies'),
(15, 'International Politics', 'International Politics');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

DROP TABLE IF EXISTS `tbl_post`;
CREATE TABLE IF NOT EXISTS `tbl_post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `cat` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `title`, `content`, `cat`) VALUES
(1, 'Cricket Live Streams Will Be Get Here', '<p>You Will be Watching the Cricket Match Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. sports match live Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First sports match live Content Goes Here. First Post Content Goes Here. </p>\r\n\r\n<p>First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. </p>\r\n\r\n<p>First Post sports match live  Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. sports match live Post Content Goes Here. First Post Content Goes Here. First Post Content Goes Here. sports match live Post Content Goes Here. First Post Content Goes Here. </p>', '5'),
(2, 'Football Match Will Be live Here', '<p>Football post content will be get here, Match Begins at 3.30 am. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second sports match live Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. </p>\r\n\r\n<p>Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. sports match live Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. </p>\r\n\r\n<p>Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second sports match live  Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. sports match live  Post Content Goes Here. Second Post Content Goes Here. Second Post Content Goes Here. </p>', '5'),
(3, 'SSC Result Will Be Published', '<p>Education board result. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third ssc Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third ssc Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. </p>\r\n\r\n<p>Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third ssc Content Goes Here. </p>\r\n\r\n<p>Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third ssc Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. Third Post Content Goes Here. </p>', '1'),
(4, 'HSC Routine Will Be Published', '<p>HSC routine contents will go here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth hsc Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth hsc Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. </p>\r\n\r\n<p>Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. </p>\r\n\r\n<p>Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth hsc Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. Fourth Post Content Goes Here. </p>', '1'),
(5, 'Election is at the Door of Bangladesh', '														<p>Election is a Huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics.</p>\r\n<p>Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics.</p>\r\n<p>Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics.</p>\r\n<p>Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics. Election is a huge part of Politics of any Country or a Nation. Same in Bangladesh, it\'s just started warming the weather in this coolest December in Bangladesh. It\'s been a very familiar scene of the winter morning in the tea stalls of Bangladesh that, that Peoples are seriously discussing about their National Politics.</p>																																																	', '14'),
(6, 'Trumph-Kim bilateral Talks', '<p>Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. </p>\r\n<p>Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. </p>\r\n<p>Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. </p>\r\n<p>Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. Now it\'s been a talk of the world that Kim gonna chat wid trumph in Singapore. Is it gonna be the big move in the International Politics ?? or the Third (3rd) World war is on the Gate. </p>										', '15'),
(7, 'Film 1.0 is breaking Records!', '<p>Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. </p>\r\n<p>Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. </p>\r\n<p>Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. Rajnikant and Akshay Kumar Starrer Film: 2.0 is just creating and breaking Records !! Amazing !! 750cr budget\'s film already earned 600cr all over the World in just 1 week + a day, Almost touching Baahubali Series. </p>', '16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ui`
--

DROP TABLE IF EXISTS `tbl_ui`;
CREATE TABLE IF NOT EXISTS `tbl_ui` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bgcolor` varchar(32) NOT NULL,
  `textcolor` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_ui`
--

INSERT INTO `tbl_ui` (`id`, `bgcolor`, `textcolor`) VALUES
(1, '#ffff80', '#ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `level`) VALUES
(1, 'admin', '4807c6a4f7a9445dfbc1363987a278cb', 1),
(2, 'author', '4807c6a4f7a9445dfbc1363987a278cb', 2),
(3, 'jamal', '4807c6a4f7a9445dfbc1363987a278cb', 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
