<style>
	
	/* Test Above */

	*{
		box-sizing: border-box;
	}

	body{
		margin: 0;
		padding: 0;
		font-family: century gothic;
		
	}

	.mycontainer{
		max-width: 1230px;
		padding-left: 15px;
		padding-right: 15px;
		margin-left: auto;
		margin-right: auto;
	}

	.mycontainer:before,
	.mycontainer:after{
		content: "";
		display: table;
		clear: both;
	}

	.m-top-bottom{
		margin-top: 15px;
		margin-bottom: 15px;
	}

	.myrow{
		margin-left: -15px;
		margin-right: -15px;
	}



	/**** CONTENT Area Start ****/
	
	.content{

	}

	/**** CONTENT Area End ****/


	/*** Common CSS Start For ALL CONTENT Area ***/

	.content-wrap{
		padding-left: 15px;
		padding-right: 15px;
	}
	.content-bg{
		background: #EBEDEF;
		color: gray;
	}

	/*** Common CSS End For ALL CONTENT Area ***/

	.go-top{
		
		background: #4e4d4d;
		color: #ebedef;
		font-weight: bold;
		font-size: 40px;
		position: fixed;
		bottom: 8px;
		right: 15px;
		z-index: +999;
		padding: 0px 7px;
		display: none;
		text-align: center;
		vertical-align: middle;
		cursor: pointer;
		opacity: .5;
	}

	/* MVC CSS Start */

	.border-right{
		border-right: 1px #ddd solid;
	}

	.post {
		padding: 10px;
	}

	.post .title h2, .post .title h2 a {
		color: #e21399;
	}

	.post .title h2 a:hover {
		text-decoration: none;
	}

	.post-border-color {
		border: 1px #e21399 solid;
		border-radius: 5px;
	}


	/* MVC CSS End */


	/* Customize bootstrap colors: Start */

	.panel-default {
	    border-color: #e21399;
	}

	.panel-default>.panel-heading {
	    color: #fff;
	    background-color: #e21399;
	    border-color: #e21399;
	}

	.bg-color {
		background-color: #e21399;
	}

	.well-color-border {
		border: 1px solid #e21399;
		color: #e21399;
	}

	.border-white {
		border: 1px #fff solid;
	}

	.category .list-group-item-default {
	    background-color: #e21399;
	}

	.category a.list-group-item-default {
	    color: #fff;
	}

	.category a.list-group-item-default:focus, a.list-group-item-default:hover {
	    color: #000;
	    background-color: #f78dc3;
	}

	.latest-post .list-group-item-default {
	    background-color: #e21399;
	}

	.latest-post a.list-group-item-default {
	    color: #fff;
	}

	.latest-post a.list-group-item-default:focus, a.list-group-item-default:hover {
	    color: #000;
	    background-color: #f78dc3;
	}

	.navbar-inverse {
	    background-color: #e21399;
	    border-color: #e21399;
	}

	.navbar-inverse .navbar-nav>li>a {
	    color: #fffefe;
	}

	.navbar-inverse .navbar-nav>li>a:focus, .navbar-inverse .navbar-nav>li>a:hover {
	    color: #000;
	    background-color: #f78dc3;
	}

	.navbar-inverse .navbar-toggle:focus, .navbar-inverse .navbar-toggle:hover {
	    background-color: #f94acc;
	}

	.navbar-inverse .navbar-toggle {
	    border-color: #f94acc;
	}

	.navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form {
	    border-color: #f94acc;
	}

	.myform .form-control:focus {
	    border-color: #e21399;
	    outline: 0;
	    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgb(226, 19, 153);
	    box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgb(226, 19, 153);
	}

	/* Customize bootstrap colors: End */

</style>