<script>
$( function() {
	$( ".menu ul li" ).click( function() {
		$( this ).attr('class' , 'cactive');
	} );
} );
</script>